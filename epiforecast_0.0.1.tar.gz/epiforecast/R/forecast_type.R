## author_header begin
## Copyright (C) 2017 Logan C. Brooks
##
## This file is part of epiforecast.  Algorithms included in epiforecast were developed by Logan C. Brooks, David C. Farrow, Sangwon Hyun, Shannon Gallagher, Ryan J. Tibshirani, Roni Rosenfeld, and Rob Tibshirani (Stanford University), members of the Delphi group at Carnegie Mellon University.
##
## Research reported in this publication was supported by the National Institute Of General Medical Sciences of the National Institutes of Health under Award Number U54 GM088491. The content is solely the responsibility of the authors and does not necessarily represent the official views of the National Institutes of Health. This material is based upon work supported by the National Science Foundation Graduate Research Fellowship Program under Grant No. DGE-1252522. Any opinions, findings, and conclusions or recommendations expressed in this material are those of the authors and do not necessarily reflect the views of the National Science Foundation. David C. Farrow was a predoctoral trainee supported by NIH T32 training grant T32 EB009403 as part of the HHMI-NIBIB Interfaces Initiative. Ryan J. Tibshirani was supported by NSF grant DMS-1309174.
## author_header end
## license_header begin
## epiforecast is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, version 2 of the License.
##
## epiforecast is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with epiforecast.  If not, see <http://www.gnu.org/licenses/>.
## license_header end

get_na_value_or_empty_for_target = function(target.info, ...) {
  bin.info = target.info[["bin_info_for"]](...)
  breaks = bin.info[["breaks"]]
  if (bin.info[["include.na"]]) {
    ## get NA of appropriate type:
    breaks[NA_integer_][[1L]]
  } else {
    breaks[integer(0)]
  }
}

get_na_string_or_empty_for_target = function(target.info, ...) {
  target.info[["unit"]][["to_string"]](
    get_na_value_or_empty_for_target(target.info, ...),
    ...
  )
}

point.mae.forecast.type = list(
  Type = "Point",
  Value_from_weighted_univals = function(target.info, target.values, target.weights, ...) {
    matrixStats::weightedMedian(target.values, target.weights, na.rm=TRUE)
  },
  Bin_start_incl_for = function(target.info, ...) {
    return (NA_character_)
  },
  Bin_end_notincl_for = function(target.info, ...) {
    return (NA_character_)
  }
)

distr.logscore.forecast.type = list(
  Type = "Bin",
  Value_from_weighted_univals = function(target.info, target.values, target.weights, label.bins=TRUE, ...) {
    ## normalize weights:
    target.weights <- target.weights/sum(target.weights)
    ## get bin weights:
    bin.info = target.info[["bin_info_for"]](...)
    stopifnot(bin.info[["include.na"]] || !any(is.na(target.values)))
    breaks = bin.info[["breaks"]]
    rightmost.closed = bin.info[["rightmost.closed"]]
    include.na = bin.info[["include.na"]]
    stopifnot(length(breaks) >= 2L && !any(is.na(breaks)))
    stopifnot(all(is.na(target.values) |
                  target.values >= breaks[[1L]] &
                  (if (rightmost.closed) target.values <= breaks[[length(breaks)]]
                  else target.values < breaks[[length(breaks)]])
                  ))
    bin = dplyr::coalesce(
                   findInterval(target.values, breaks,
                                rightmost.closed=rightmost.closed,
                                all.inside=TRUE),
                   length(breaks))
    nbins = length(breaks)-1L + as.integer(include.na)
    bin.weights = weighted_tabulate(bin, nbins, target.weights)
    if (label.bins) {
      left.delimiter = "["
      left.break.string = target.info[["unit"]][["to_string"]](
        breaks[-length(breaks)], ...
      )
      right.break.string = target.info[["unit"]][["to_string"]](
        breaks[-1L], ...
      )
      right.delimiter =
        if (rightmost.closed) c(rep(")", length(breaks)-2L), "]")
        else ")"
      bin.names = c(
        paste0(left.delimiter, left.break.string, ", ",
               right.break.string, right.delimiter),
        get_na_string_or_empty_for_target(target.info, ...)
        )
      names(bin.weights) <- bin.names
    }
    return (bin.weights)
  },
  Bin_start_incl_for = function(target.info, ...) {
    bin.info = target.info[["bin_info_for"]](...)
    breaks = bin.info[["breaks"]]
    Bin_start_incl = c(
      target.info[["unit"]][["to_string"]](
        breaks[-length(breaks)], ...
      ),
      get_na_string_or_empty_for_target(target.info, ...)
    )
    return (Bin_start_incl)
  },
  Bin_end_notincl_for = function(target.info, ...) {
    bin.info = target.info[["bin_info_for"]](...)
    breaks = bin.info[["breaks"]]
    Bin_end_notincl = c(
      target.info[["unit"]][["to_string"]](
        breaks[-1L], ...
      ),
      get_na_string_or_empty_for_target(target.info, ...)
    )
    return (Bin_end_notincl)
  }
)

partial_spreadsheet_from_weighted_univals =
  function(forecast.type, target.info,
           target.values, target.weights,
           only.Value=FALSE,
           ...) {
    Value = forecast.type[["Value_from_weighted_univals"]](target.info, target.values, target.weights, label.bins=FALSE, ...)
    if (only.Value) {
      return (tibble::tibble(Value=Value))
    } else {
      partial.spreadsheet =
        tibble::tibble(
                  Target=target.info[["Target"]],
                  Type=forecast.type[["Type"]],
                  Unit=target.info[["unit"]][["Unit"]],
                  Bin_start_incl=forecast.type[["Bin_start_incl_for"]](target.info, ...),
                  Bin_end_notincl=forecast.type[["Bin_end_notincl_for"]](target.info, ...),
                  Value=Value
                )
      return (partial.spreadsheet)
    }
}

