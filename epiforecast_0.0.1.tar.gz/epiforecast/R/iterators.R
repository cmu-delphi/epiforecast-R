library(parallel)

## each_ = function(dims) {
## }

## itapply/iterply/applyit/expandit/prodit --- S3 function (arrays/array-like, data frames)

## it_array_length

## Individual iterators:
##   array_length : array-like -> single integer --- is this necessary given the next thing?
##   index_sets : array-like -> possibly named vector/list of indexing things --- NO, doesn't work for simultaneous iterators (even ignoring those, requires a way to specify the corresponding dimension)
##   subapply : array-like -> array-like subresult --- NO, not friendly for parallelism?
## (possibility of warm starts somehow?)
## should results be stored in a list-pair with the first list holding compressed indices (single-integer indices) and the second holding the results?
## (how to handle mixed-format stuff, mixed-error stuff, ...)
