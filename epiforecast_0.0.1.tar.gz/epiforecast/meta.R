## Commands to create a vignette
vignettename = "fetch_data"
devtools::use_vignette(vignettename)

