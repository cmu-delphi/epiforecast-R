context("Testing the br.sim() function..")

## ## Make a sim object from fluview.
## full.dat = fetchEpidataFullDat("fluview", "hhs1", "wili",
##                                min.points.in.season=52L,
##                                first.week.of.season = 21L,
##                                cache.file=sprintf("fluview_%s_fetch.Rdata", area.name))
## mysim = br.sim(full.dat, n.sims=100)

## ## Tests:

## test_that("Returns object of class 'sim'.", {
##     expect_equal(class(mysim),"sim")
## })
